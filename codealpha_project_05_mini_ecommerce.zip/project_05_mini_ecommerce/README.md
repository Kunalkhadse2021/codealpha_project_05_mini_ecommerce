# Interactive Mini E-Commerce App

## CodeAlpha Project 05

A beginner-friendly mini online store with a dynamic product catalog, interactive shopping cart and checkout preview modal.

## Features

- Product catalog rendered from JavaScript objects
- Add products to the shopping cart
- Increase and decrease item quantities
- Remove an item by reducing its quantity to zero
- Live cart item count
- Automatic subtotal calculation
- Clear cart button
- Checkout preview modal
- Responsive desktop, tablet and mobile layout

## Technologies Used

- HTML5
- CSS3
- JavaScript
- DOM manipulation
- JavaScript arrays and objects
- Event listeners
- Modal interaction

## Project Files

- `index.html` — page structure and checkout modal
- `style.css` — responsive design and product cards
- `script.js` — product data, cart logic and checkout preview
- `README.md` — project documentation

## How to Run

1. Extract the project ZIP.
2. Open the project folder in Visual Studio Code.
3. Open `index.html` in a browser or use Live Server.
4. Click Add to cart on any product.
5. Change item quantities in the cart.
6. Click Continue to checkout to view the order preview.

## Customize Products

Open `script.js` and edit the `products` array. Each product has an ID, name, category, description, price and emoji.

Prices are displayed in Indian Rupees (INR). Change the currency in the `formatPrice()` function if required.

## Important Note

This is a front-end demonstration project. It does not connect to a payment gateway, process real payments, or store orders on a server.

## Author

Kunal Khadse

## Conclusion

This project demonstrates dynamic product rendering, cart management, quantity handling, price calculation and modal checkout interaction using JavaScript.
