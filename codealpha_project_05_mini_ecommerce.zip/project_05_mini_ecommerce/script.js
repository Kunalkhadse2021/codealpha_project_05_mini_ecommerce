// MINI E-COMMERCE APP
// Product data is stored as JavaScript objects.

const products = [
  { id: 1, name: "Wireless Headphones", category: "Electronics", description: "Comfortable sound for work and travel.", price: 2499, emoji: "🎧" },
  { id: 2, name: "Smart Watch", category: "Electronics", description: "A simple companion for every day.", price: 3299, emoji: "⌚" },
  { id: 3, name: "Backpack", category: "Accessories", description: "Roomy design for everyday essentials.", price: 1499, emoji: "🎒" },
  { id: 4, name: "Running Shoes", category: "Fashion", description: "Lightweight comfort for active days.", price: 2199, emoji: "👟" },
  { id: 5, name: "Coffee Mug", category: "Home", description: "Your favorite drink, your favorite mug.", price: 399, emoji: "☕" },
  { id: 6, name: "Desk Lamp", category: "Home", description: "A warm glow for your workspace.", price: 899, emoji: "💡" },
  { id: 7, name: "Sunglasses", category: "Accessories", description: "A clean look for sunny days.", price: 799, emoji: "🕶️" },
  { id: 8, name: "Notebook", category: "Stationery", description: "Capture plans, ideas and notes.", price: 249, emoji: "📓" }
];

const productGrid = document.getElementById("productGrid");
const productCount = document.getElementById("productCount");
const cartItems = document.getElementById("cartItems");
const cartCount = document.getElementById("cartCount");
const cartTotal = document.getElementById("cartTotal");
const checkoutButton = document.getElementById("checkoutButton");
const clearCartButton = document.getElementById("clearCartButton");
const cartButton = document.getElementById("cartButton");

const checkoutModal = document.getElementById("checkoutModal");
const closeModalButton = document.getElementById("closeModalButton");
const finishButton = document.getElementById("finishButton");
const checkoutSummary = document.getElementById("checkoutSummary");

let cart = [];

function formatPrice(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2
  }).format(value);
}

// Render product cards dynamically from the products array.
function renderProducts() {
  productGrid.innerHTML = "";
  productCount.textContent = `${products.length} products`;

  products.forEach((product) => {
    const card = document.createElement("article");
    card.className = "product-card";

    const art = document.createElement("div");
    art.className = "product-art";
    art.textContent = product.emoji;
    art.setAttribute("aria-hidden", "true");

    const info = document.createElement("div");
    info.className = "product-info";

    const category = document.createElement("p");
    category.className = "product-category";
    category.textContent = product.category;

    const name = document.createElement("h3");
    name.textContent = product.name;

    const description = document.createElement("p");
    description.className = "product-description";
    description.textContent = product.description;

    const bottom = document.createElement("div");
    bottom.className = "product-bottom";

    const price = document.createElement("span");
    price.className = "product-price";
    price.textContent = formatPrice(product.price);

    const addButton = document.createElement("button");
    addButton.className = "add-button";
    addButton.type = "button";
    addButton.textContent = "Add to cart";
    addButton.addEventListener("click", () => addToCart(product.id));

    bottom.append(price, addButton);
    info.append(category, name, description, bottom);
    card.append(art, info);
    productGrid.appendChild(card);
  });
}

// Add a product or increase its quantity in the cart.
function addToCart(productId) {
  const existingItem = cart.find(item => item.id === productId);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ id: productId, quantity: 1 });
  }

  renderCart();
}

// Change the quantity of a cart item.
function changeQuantity(productId, change) {
  const item = cart.find(entry => entry.id === productId);
  if (!item) return;

  item.quantity += change;

  if (item.quantity <= 0) {
    cart = cart.filter(entry => entry.id !== productId);
  }

  renderCart();
}

// Calculate the total number of products in the cart.
function getCartCount() {
  return cart.reduce((total, item) => total + item.quantity, 0);
}

// Calculate the cart subtotal.
function getCartTotal() {
  return cart.reduce((total, item) => {
    const product = products.find(product => product.id === item.id);
    return total + product.price * item.quantity;
  }, 0);
}

// Render cart rows and update totals.
function renderCart() {
  cartItems.innerHTML = "";

  if (cart.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-cart";
    empty.textContent = "Your cart is empty. Add a product to get started.";
    cartItems.appendChild(empty);
  } else {
    cart.forEach(item => {
      const product = products.find(entry => entry.id === item.id);
      const row = document.createElement("div");
      row.className = "cart-row";

      const productInfo = document.createElement("div");
      productInfo.className = "cart-product";

      const emoji = document.createElement("span");
      emoji.className = "cart-emoji";
      emoji.textContent = product.emoji;

      const details = document.createElement("div");
      const name = document.createElement("strong");
      name.textContent = product.name;
      const unitPrice = document.createElement("small");
      unitPrice.textContent = `${formatPrice(product.price)} each`;
      details.append(name, unitPrice);
      productInfo.append(emoji, details);

      const controls = document.createElement("div");
      controls.className = "quantity-controls";

      const minus = document.createElement("button");
      minus.type = "button";
      minus.textContent = "−";
      minus.setAttribute("aria-label", `Remove one ${product.name}`);
      minus.addEventListener("click", () => changeQuantity(product.id, -1));

      const quantity = document.createElement("span");
      quantity.textContent = item.quantity;

      const plus = document.createElement("button");
      plus.type = "button";
      plus.textContent = "+";
      plus.setAttribute("aria-label", `Add one ${product.name}`);
      plus.addEventListener("click", () => changeQuantity(product.id, 1));

      controls.append(minus, quantity, plus);

      const lineTotal = document.createElement("strong");
      lineTotal.className = "line-total";
      lineTotal.textContent = formatPrice(product.price * item.quantity);

      row.append(productInfo, controls, lineTotal);
      cartItems.appendChild(row);
    });
  }

  cartCount.textContent = getCartCount();
  cartTotal.textContent = formatPrice(getCartTotal());
  checkoutButton.disabled = cart.length === 0;
}

// Clear all cart items.
function clearCart() {
  cart = [];
  renderCart();
}

// Create and show the checkout preview modal.
function openCheckoutPreview() {
  if (cart.length === 0) return;

  checkoutSummary.innerHTML = "";

  cart.forEach(item => {
    const product = products.find(entry => entry.id === item.id);
    const line = document.createElement("div");
    line.className = "summary-line";

    const itemName = document.createElement("span");
    itemName.textContent = `${product.name} × ${item.quantity}`;

    const itemPrice = document.createElement("strong");
    itemPrice.textContent = formatPrice(product.price * item.quantity);

    line.append(itemName, itemPrice);
    checkoutSummary.appendChild(line);
  });

  const total = document.createElement("div");
  total.className = "summary-total";

  const label = document.createElement("span");
  label.textContent = "Order total";

  const value = document.createElement("strong");
  value.textContent = formatPrice(getCartTotal());

  total.append(label, value);
  checkoutSummary.appendChild(total);

  checkoutModal.hidden = false;
  closeModalButton.focus();
}

function closeCheckoutPreview() {
  checkoutModal.hidden = true;
  checkoutButton.focus();
}

// Button events.
clearCartButton.addEventListener("click", clearCart);
checkoutButton.addEventListener("click", openCheckoutPreview);

cartButton.addEventListener("click", () => {
  document.getElementById("cartSection").scrollIntoView({
    behavior: "smooth",
    block: "start"
  });
});

closeModalButton.addEventListener("click", closeCheckoutPreview);

checkoutModal.addEventListener("click", (event) => {
  if (event.target.hasAttribute("data-close-modal")) {
    closeCheckoutPreview();
  }
});

// Finish is a demo action, not a real purchase.
finishButton.addEventListener("click", () => {
  alert("Demo checkout complete! No real payment was processed.");
  checkoutModal.hidden = true;
  cart = [];
  renderCart();
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !checkoutModal.hidden) {
    closeCheckoutPreview();
  }
});

// Initial page rendering.
renderProducts();
renderCart();
